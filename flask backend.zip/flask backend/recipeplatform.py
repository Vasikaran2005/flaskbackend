from flask import Flask, request, jsonify
from flask_cors import CORS
import tensorflow as tf
import numpy as np
from PIL import Image
import requests
import os

app = Flask(__name__)
CORS(app)  # Allow frontend to communicate with backend

# AWS S3 URL for model.h5
MODEL_URL = "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/ingredient_model+(1).h5"
MODEL_PATH = "C:\Recipesharingplatform\Recipe Platform\ingredient_model (1).h5"

# Function to download model if not exists
def download_model():
    if not os.path.exists(MODEL_PATH):
        print("Downloading model from S3...")
        response = requests.get(MODEL_URL)
        os.makedirs("models", exist_ok=True)
        with open(MODEL_PATH, "wb") as f:
            f.write(response.content)
        print("Download complete!")

download_model()
model = tf.keras.models.load_model(MODEL_PATH)

# Define Recipe Labels (Replace with actual ones)
class_labels = ["Ghevar", "Gulab jamun", "Kaju katli", "Laddu", "Pongal", "Tandoori Chicken", "Rasam", "Parupu Vada", "Prawn malai curry", "Kadai paneer", "Chicken Tikka masala", "Dal makhani", "Kachori", "Chana masala", "Chapati", "Kuzhi paniyaram", "Mysore pak", "Adhirasam", "Bandar laddu", "Kofta", "Kulfi falooda", "Thayir sadam", "Pav Bhaji", "Payasam", "Paruppu sadam", "Puli sadam", "Chicken Varuval", "Jalebi", "Lassi", "Naan", "Palak paneer", "Paneer butter masala", "Paneer tikka masala", "Pani puri", "Paratha", "Samosa", "Shahi paneer", "Shahi tukra", "Dosa", "Idiappam", "Idli", "Kanji", "Kaara kozhambu", "Keerai kootu", "Kuzhakkattai", "Beef Fry", "Bisi bele bath", "Boondi", "Ajmeer Kova", "Aloo gobi"]

# Recipe details dictionary (Replace with actual data)
recipe_details = {
    "Ghevar": {
        "Procedure": "Mix a thin batter of ghee, flour, milk, and water, then deep fry it into a honeycomb-like disc. Dip in sugar syrup, garnish with nuts, and enjoy!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Ghevar.jpg"
    },
    "Gulab jamun": {
        "Procedure": "Make a dough with milk powder, flour, ghee, and milk, shape into small balls, and deep fry until golden. Soak in warm sugar syrup flavored with cardamom and rose water, then serve!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Gulab+jamun.jpg"
    },
    "Kaju katli": {
        "Procedure": "Cook cashew powder with sugar syrup until it forms a dough, then roll it out and cut into diamond shapes. Garnish with silver vark and enjoy!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Kaju+katli.jpg"
    },
    "Laddu": {
        "Procedure": "Roast flour or semolina with ghee, mix with sugar and nuts, then shape into balls while warm. Let them cool and serve!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Laddu.jpg"
    },
    "Pongal": {
        "Procedure": "Cook rice and moong dal together, then season with ghee, black pepper, cumin, and cashews for savory Pongal. For sweet Pongal, add jaggery, cardamom, and nuts. Serve warm!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Pongal.jpg"
    },
    "Tandoori Chicken": {
        "Procedure": "Marinate chicken in yogurt, spices, lemon juice, and garlic-ginger paste, then grill or bake until smoky and charred. Serve hot with onion rings and mint chutney!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Tandoori+Chicken.jpg"
    },
    "Rasam":{
        "Procedure": "Boil tamarind water with tomatoes, spices, and cooked dal, then temper with mustard seeds, curry leaves, and red chilies in ghee. Serve hot with rice!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Rasam.jpg"
    },
    "Parupu Vada": {
        "Procedure": "Grind soaked urad dal into a smooth batter, add spices and herbs, then shape into donuts. Deep fry until golden and serve with chutney or sambar!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Parupu+Vada.jpg"
    },
    "Prawn malai curry":{
        "Procedure": "Cook prawns in a creamy coconut milk base with spices like turmeric, cumin, and garam masala, then simmer until tender. Serve hot with rice or naan!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Prawn+malai+curry.jpg"
    },
    "Kadai paneer":{
        "Procedure": "Stir-fry paneer cubes with bell peppers, onions, tomatoes, and a blend of spices like garam masala, coriander, and cumin in a wok. Serve hot with naan or rice!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Kadai+paneer.jpg"
    },
    "Chicken Tikka masala":{
        "Procedure": "Marinate chicken in yogurt and spices, then grill or bake. Cook the grilled chicken in a rich, creamy tomato gravy with garam masala, onions, and cream. Serve with rice or naan!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Chicken+Tikka+masala.jpg"
    },
    "Dal makhani":{
        "Procedure": "Cook black lentils (urad dal) and kidney beans (rajma) with spices, then simmer in a creamy tomato-based gravy with butter and cream. Serve hot with naan or rice!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Dal+makhani.jpg"
    },
    "Kachori":{
        "Procedure": "Stuff a dough ball with spiced lentil or potato filling, shape into a round, and deep fry until golden and crispy. Serve with tamarind chutney or yogurt!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Kachori.jpg"
    },
    "Chana masala":{
        "Procedure": "Cook chickpeas in a spiced tomato gravy with onions, garlic, ginger, and garam masala. Serve hot with rice or naan!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Chana+masala.jpg"
    },
    "Chapati":{
        "Procedure": "Knead whole wheat flour with water and salt into a smooth dough, roll into thin discs, and cook on a hot tawa until puffed and lightly browned. Serve hot with curry or dals!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Chapati.jpg"
    },
    "Kuzhi paniyaram":{
        "Procedure": "Make a batter with fermented idli/dosa mix, then pour into a paniyaram pan with oil, adding mustard seeds, curry leaves, and onions. Cook until crispy and golden, and serve with chutney!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Kuzhi+paniyaram.jpg"
    },
    "Mysore pak":{
        "Procedure": "Cook besan (gram flour) with ghee and sugar syrup until it thickens and starts to leave the sides of the pan. Set in a greased tray, cut into pieces, and serve!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Mysore+pak.jpg"
    },
    "Adhirasam":{
        "Procedure": "Make a dough with rice flour, jaggery, and spices, then shape into rings. Deep fry until golden brown and crispy, and serve hot!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Adhirasam.jpg"
    },
    "Bandar laddu":{
        "Procedure": "Mix roasted gram flour with sugar, ghee, and cardamom powder, then shape into round balls. Let them cool and enjoy the sweet, nutty flavor!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Bandar+laddu.jpg"
    },
    "Kofta":{
        "Procedure": "Make a filling with mashed vegetables or paneer, spice it up, shape into balls, and deep fry. Simmer the koftas in a rich, spiced tomato gravy and serve with rice or naan!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Kofta.jpg"
    },
    "Kulfi falooda":{
        "Procedure": "Serve kulfi (creamy frozen dessert) on a bed of falooda (sweetened rose water noodles) topped with fruit, nuts, and rose syrup. Enjoy this refreshing, layered dessert!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Kulfi+falooda.jpg"
    },
    "Thayir sadam":{
        "Procedure": "Mix cooked rice with yogurt, mustard seeds, curry leaves, green chilies, and a pinch of asafetida. Serve chilled as a refreshing side dish!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Thayir+sadam.jpg"
    },
    "Pav Bhaji":{
        "Procedure": "Cook mixed vegetables in a spiced tomato gravy, then mash them together to form a thick, flavorful bhaji. Serve with buttered, toasted pav rolls, and garnish with onions and cilantro!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Pav+Bhaji.jpg"
    },
    "Payasam":{
        "Procedure": "Cook rice or vermicelli in milk with sugar, cardamom, and saffron, then garnish with nuts and raisins fried in ghee. Serve warm or chilled!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Payasam.jpg"
    },
    "Paruppu sadam":{
        "Procedure": "Mix cooked rice with a spiced dal (parupu) made from toor dal, curry leaves, mustard seeds, and ghee. Serve with a side of yogurt or pickle!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Paruppu+sadam.JPG"
    },
    "Puli sadam":{
        "Procedure": "Cook rice with tamarind extract, mustard seeds, curry leaves, and a blend of spices like red chili powder and turmeric. Serve with a side of papadam or pickle!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Puli+sadam.jpg"
    },
    "Chicken Varuval":{
        "Procedure": "Marinate chicken with spices, ginger-garlic paste, and lemon juice, then fry it until crispy and golden. Serve hot as a spicy, flavorful appetizer or side dish!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Chicken+Varuval.jpg"
    },
    "Jalebi":{
        "Procedure": "Make a batter with flour, yogurt, and water, then pipe it into hot oil in a spiral shape and fry until crispy. Soak in sugar syrup flavored with saffron and rose water, then serve warm!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Jalebi.jpg"
    },
    "Lassi":{
        "Procedure": "Blend yogurt, water, and sugar (or salt for a savory version) with ice cubes to make a smooth, refreshing drink. Garnish with a pinch of cardamom or mint leaves and serve chilled!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Lassi.jpg"
    },
    "Naan":{
        "Procedure": "Mix flour, yogurt, yeast, and baking powder into a soft dough, let it rise, then roll it into flatbreads. Cook on a hot tawa or in a tandoor until puffed and golden, then brush with butter.",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Naan.jpg"
    },
    "Palak paneer":{
        "Procedure": "Cook spinach (palak) with spices, blend into a smooth puree, and simmer with paneer cubes in a rich, spiced gravy. Serve hot with naan or rice!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Palak+paneer.jpg"
    },
    "Paneer butter masala":{
        "Procedure": "Cook paneer in a rich, creamy tomato gravy with butter, cream, and spices like garam masala, cumin, and kasuri methi. Serve hot with naan or rice!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Paneer+butter+masala.jpg"
    },
    "Paneer tikka masala":{
        "Procedure": "Grill or bake marinated paneer cubes, then cook them in a rich, spiced tomato gravy with cream, butter, and garam masala. Serve hot with naan or rice!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Paneer+tikka+masala.jpg"
    },
    "Pani puri":{
        "Procedure": "Fill crispy puris with spiced potato filling, pour in tangy tamarind water (pani), and serve immediately for a burst of flavor!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Pani+puri.jpg"
    },
    "Paratha":{
        "Procedure": "Knead whole wheat flour into a soft dough, roll it into a flat disc, and cook on a hot tawa with ghee or oil until golden brown. Serve with curry, yogurt, or pickle!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Paratha.jpg"
    },
    "Samosa":{
        "Procedure": "Fill a crispy, triangular pastry shell with spiced potatoes and peas, then deep fry until golden and crunchy. Serve with chutney or yogurt!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Samosa.jpg"
    },
    "Shahi paneer":{
        "Procedure": "Cook paneer in a rich, creamy gravy made with yogurt, cream, almonds, and aromatic spices like cardamom and saffron. Serve hot with naan or rice!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Shahi+paneer.jpg"
    },
    "Shahi tukra":{
        "Procedure": "Fry bread slices in ghee, then soak in sugar syrup flavored with cardamom. Top with a rich, creamy milk mixture, and garnish with nuts and saffron. Serve warm!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Shahi+tukra.jpg"
    },
    "Dosa":{
        "Procedure": "Ferment a batter made of rice and urad dal, then spread it thin on a hot griddle to make a crispy, golden crepe. Serve with chutney and sambar!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Dosa.jpg"
    },
    "Idiappam":{
        "Procedure": "Steam rice flour dough into noodle-like strands, then serve with coconut milk, curry, or stew for a delicious meal!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Idiappam.jpg"
    },
    "Idli":{
        "Procedure": "Ferment a batter of rice and urad dal, then steam the batter in idli molds until soft and fluffy. Serve with sambar and chutney!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Idiappam.jpg"
    },
    "Kanji":{
        "Procedure": "Cook rice with water and spices like mustard seeds, curry leaves, and asafetida, then let it ferment slightly. Serve warm, often as a comfort food with pickle or papadam!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Kanji.jpg"
    },
    "Kaara kozhambu":{
        "Procedure": "Cook tamarind, tomatoes, and spices like mustard seeds, fenugreek, and curry leaves in a tangy, spicy gravy. Add vegetables or meat, and simmer until flavors meld. Serve hot with rice!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Kaara+kozhambu.jpg"
    },
    "Keerai kootu":{
        "Procedure": "Cook spinach (keerai) with toor dal, coconut, and spices like mustard seeds and cumin. Simmer together into a thick, flavorful stew and serve with rice!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Keerai+kootu.jpg"
    },
    "Kuzhakkattai":{
        "Procedure": "Make a dough with rice flour, stuff it with a spiced mixture of coconut and jaggery or savory filling, then steam the dumplings until cooked. Serve with coconut chutney or sambar!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Kuzhakkattai.jpg"
    },
    "Beef Fry":{
        "Procedure": "Cook beef with spices like garam masala, ginger-garlic paste, and onions until tender, then fry it until crispy and browned. Serve hot with rice or paratha!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Beef+Fry.jpg"
    },
    "Bisi bele bath":{
        "Procedure": "Cook rice and lentils with tamarind, vegetables, and a special Bisi Bella Bath masala, then temper with mustard seeds, curry leaves, and ghee. Serve hot with papad or raita!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Bisi+bele+bath.jpg"
    },
    "Boondi":{
        "Procedure": "Fry small, round boondi (chickpea flour balls) in hot oil, then soak in warm sugar syrup flavored with saffron and cardamom. Serve as a sweet snack or dessert!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Boondi.jpg"
    },
    "Ajmeer Kova":{
        "Procedure": "Prepare a mixture of mawa (khoya), sugar, and cardamom, then cook until it thickens into a fudgy consistency. Shape into small balls or bars and garnish with nuts.",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Ajmeer+Kova.jpg"
    },
    "Aloo gobi":{
        "Procedure": "Cook potatoes and cauliflower with spices like turmeric, cumin, coriander, and garam masala until tender and flavorful. Serve hot with roti or rice!",
        "image": "https://recipe-model-storage.s3.ap-south-1.amazonaws.com/recipeimages/Aloo+gobi.jpg"
    }
}

@app.route("/predict_recipe", methods=["POST"])
def predict_recipe():
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    file = request.files["file"]
    image = Image.open(file).resize((224, 224))  # Resize as per model requirement
    image = np.array(image) / 255.0  # Normalize
    image = np.expand_dims(image, axis=0)  # Add batch dimension

    # Make Prediction
    predictions = model.predict(image)
    predicted_class = class_labels[np.argmax(predictions)]

    # Get recipe details
    recipe_info = recipe_details.get(predicted_class, {})
    
    return jsonify({
        "predicted_recipe": predicted_class,
        "procedure": recipe_info.get("procedure", "Procedure not found."),
        "image": recipe_info.get("image", "https://your-bucket.s3.amazonaws.com/default.jpg")
    })

if __name__ == "__main__":
    app.run(debug=True)
